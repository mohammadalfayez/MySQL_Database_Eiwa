DROP DATABASE IF EXISTS eiwa;

-- Create the database
CREATE DATABASE eiwa CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- Use the new database
USE eiwa;

CREATE TABLE `أقسام` (
    `اسم_القسم` VARCHAR(100) PRIMARY KEY,
    `وصف_القسم` TEXT,
    `عدد_الموظفين` INT DEFAULT 0
);

CREATE TABLE `موظفين` (
    `رقم_الموظف` INT PRIMARY KEY,
    `قسم` VARCHAR(100),
    `اسم_الموظف` VARCHAR(100),
    `تاريخ_الميلاد` DATE,
    `رقم_الهاتف` VARCHAR(20),
    `وظيفة` VARCHAR(100),
    `تاريخ_التوظيف` DATE,
    `مدفوع_الراتب` BOOLEAN,
    `تاريخ_دفع_الراتب` DATE,
    `أيام_الإجازة_السنوية` INT,
    `أيام_الإجازة_التي_استخدمت` INT,
    FOREIGN KEY (`قسم`) REFERENCES `أقسام`(`اسم_القسم`) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE `حوادث_الموظفين` (
    `رقم_الحادث` INT PRIMARY KEY,
    `رقم_الموظف` INT,
    `سبب_الحادث` TEXT,
    `وصف_الحادث` TEXT,
    `تاريخ_الحادث` DATE,
    `الخطورة` VARCHAR(100),
    FOREIGN KEY (`رقم_الموظف`) REFERENCES `موظفين`(`رقم_الموظف`) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE `مجموعات_الطلاب` (
    `رقم_المجموعة` INT PRIMARY KEY,
    `عدد_الطلاب` INT DEFAULT 0,
    `وصف_المجموعة` TEXT
);

CREATE TABLE `مسؤولون_مجموعة_الطلاب` (
    `رقم_المسئول` INT,
    `رقم_المجموعة` INT,
    PRIMARY KEY (`رقم_المسئول`, `رقم_المجموعة`),
    FOREIGN KEY (`رقم_المسئول`) REFERENCES `موظفين`(`رقم_الموظف`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`رقم_المجموعة`) REFERENCES `مجموعات_الطلاب`(`رقم_المجموعة`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `الغرف` (
    `رقم_الغرفة` INT PRIMARY KEY,
    `موقع_الغرفة` VARCHAR(100),
    `مساحة_الغرقة` VARCHAR(100),
    `عدد_الأسر` INT,
    `عدد_الطلاب` INT DEFAULT 0,
    `الحد_الاقصى` INT,
    `الحالة` VARCHAR(100),
    `وجود_وسع` BOOLEAN
);

CREATE TABLE `الطلاب` (
    `رقم_الطالب` INT PRIMARY KEY,
    `رقم_المجموعة` INT,
    `رقم_الغرفة` INT,
    `اسم_الطالب` VARCHAR(100),
    `تاريخ_الميلاد` DATE,
    `رقم_الهاتف` VARCHAR(20),
    FOREIGN KEY (`رقم_المجموعة`) REFERENCES `مجموعات_الطلاب`(`رقم_المجموعة`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`رقم_الغرفة`) REFERENCES `الغرف`(`رقم_الغرفة`) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE `حوادث_الطلاب` (
    `رقم_الحادث` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `وصف_الحادث` TEXT,
    `تاريخ_الحادث` DATE,
    `الخطورة` VARCHAR(100),
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `المجال_الحركي` (
    `رقم_نموذج_المجال_الحركي` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `الاتزان_اثناء_الحركة` TEXT,
    `اصعاد_ونزول_الدرج` TEXT,
    `ضغط_على_الكرة_الاسفنجية` TEXT,
    `قفز_من_ارتفاع_محدد` TEXT,
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `المجال_الاجتماعي` (
    `رقم_نموذج_المجال_الاجتماعي` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `مصافحة_من_تلقاء_نفسه` TEXT,
    `التحية_على_الاخرين` TEXT,
    `طرق_الباب_قبل_الدخول` TEXT,
    `تقبل_الغرباء` TEXT,
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `المجال_الاستقلالي` (
    `رقم_نموذج_المجال_الاستقلالي` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `استخدام_الحمام` TEXT,
    `غسل_اليدين_وتنشيف` TEXT,
    `لبس_وخلع_الملابس` TEXT,
    `تناول_الطعام_باستقلال` TEXT,
    `فرش_الاسنان` TEXT,
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `المجال_الادراكي` (
    `رقم_نموذج_المجال_الادراكي` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `مطابقة_الاشياء_المماثلة` TEXT,
    `مطابقة_الاشكال_الهندسية` TEXT,
    `تسمية_الالوان_الاساسية` TEXT,
    `مطابقة_الاحجام` TEXT,
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE `نموذج_طبي` (
    `رقم_النموذج_الطبي` INT PRIMARY KEY,
    `رقم_الطالب` INT,
    `تشخيص` TEXT,
    `وصفة_طبية` TEXT,
    `حساسية_للادوية` TEXT,
    `حساسية_للطعام` TEXT,
    FOREIGN KEY (`رقم_الطالب`) REFERENCES `الطلاب`(`رقم_الطالب`) ON DELETE CASCADE ON UPDATE CASCADE
);

DELIMITER //

CREATE TRIGGER `after_employee_insert`
AFTER INSERT ON `موظفين`
FOR EACH ROW
BEGIN
    UPDATE `أقسام`
    SET `عدد_الموظفين` = `عدد_الموظفين` + 1
    WHERE `اسم_القسم` = NEW.`قسم`;
END//

DELIMITER ;

DELIMITER //

CREATE TRIGGER `after_employee_delete`
AFTER DELETE ON `موظفين`
FOR EACH ROW
BEGIN
    UPDATE `أقسام`
    SET `عدد_الموظفين` = `عدد_الموظفين` - 1
    WHERE `اسم_القسم` = OLD.`قسم`;
END//

DELIMITER ;

DELIMITER //

CREATE TRIGGER `after_employee_update`
AFTER UPDATE ON `موظفين`
FOR EACH ROW
BEGIN
    -- Check if the department was changed
    IF OLD.`قسم` IS NOT NULL AND OLD.`قسم` != NEW.`قسم` THEN
        -- Decrement the employee count in the old department
        UPDATE `أقسام`
        SET `عدد_الموظفين` = `عدد_الموظفين` - 1
        WHERE `اسم_القسم` = OLD.`قسم`;
    END IF;

    -- Increment the employee count in the new department if it is not NULL
    IF NEW.`قسم` IS NOT NULL AND OLD.`قسم` != NEW.`قسم` THEN
        UPDATE `أقسام`
        SET `عدد_الموظفين` = `عدد_الموظفين` + 1
        WHERE `اسم_القسم` = NEW.`قسم`;
    END IF;
END//

DELIMITER ;

DELIMITER //

CREATE TRIGGER `after_student_insert`
AFTER INSERT ON `الطلاب`
FOR EACH ROW
BEGIN
    UPDATE `مجموعات_الطلاب`
    SET `عدد_الطلاب` = `عدد_الطلاب` + 1
    WHERE `رقم_المجموعة` = NEW.`رقم_المجموعة`;

    UPDATE `الغرف`
    SET `عدد_الطلاب` = `عدد_الطلاب` + 1
    WHERE `رقم_الغرفة` = NEW.`رقم_الغرفة`;
END//

DELIMITER ;

DELIMITER //

CREATE TRIGGER `after_student_delete`
AFTER DELETE ON `الطلاب`
FOR EACH ROW
BEGIN
    UPDATE `مجموعات_الطلاب`
    SET `عدد_الطلاب` = `عدد_الطلاب` - 1
    WHERE `رقم_المجموعة` = OLD.`رقم_المجموعة`;

    UPDATE `الغرف`
    SET `عدد_الطلاب` = `عدد_الطلاب` - 1
    WHERE `رقم_الغرفة` = OLD.`رقم_الغرفة`;
END//

DELIMITER ;

DELIMITER //

CREATE TRIGGER `after_student_update`
AFTER UPDATE ON `الطلاب`
FOR EACH ROW
BEGIN
    -- Check if the group was changed
    IF OLD.`رقم_المجموعة` IS NOT NULL AND OLD.`رقم_المجموعة` != NEW.`رقم_المجموعة` THEN
        -- Decrement the student count in the old group
        UPDATE `مجموعات_الطلاب`
        SET `عدد_الطلاب` = `عدد_الطلاب` - 1
        WHERE `رقم_المجموعة` = OLD.`رقم_المجموعة`;
    END IF;

    -- Increment the student count in the new group if it is not NULL
    IF NEW.`رقم_المجموعة` IS NOT NULL AND OLD.`رقم_المجموعة` != NEW.`رقم_المجموعة` THEN
        UPDATE `مجموعات_الطلاب`
        SET `عدد_الطلاب` = `عدد_الطلاب` + 1
        WHERE `رقم_المجموعة` = NEW.`رقم_المجموعة`;
    END IF;

    -- Check if the room was changed
    IF OLD.`رقم_الغرفة` IS NOT NULL AND OLD.`رقم_الغرفة` != NEW.`رقم_الغرفة` THEN
        -- Decrement the student count in the old room
        UPDATE `الغرف`
        SET `عدد_الطلاب` = `عدد_الطلاب` - 1
        WHERE `رقم_الغرفة` = OLD.`رقم_الغرفة`;
    END IF;

    -- Increment the student count in the new room if it is not NULL
    IF NEW.`رقم_الغرفة` IS NOT NULL AND OLD.`رقم_الغرفة` != NEW.`رقم_الغرفة` THEN
        UPDATE `الغرف`
        SET `عدد_الطلاب` = `عدد_الطلاب` + 1
        WHERE `رقم_الغرفة` = NEW.`رقم_الغرفة`;
    END IF;
END//

DELIMITER ;