Use eiwa;
INSERT INTO `أقسام` (`اسم_القسم`, `وصف_القسم`, `عدد_الموظفين`) VALUES
('IT', 'Information Technology', 0),
('HR', 'Human Resources', 0),
('Finance', 'Finance Department', 0),
('Marketing', 'Marketing Department', 0),
('Sales', 'Sales Department', 0),
('Legal', 'Legal Department', 0),
('Operations', 'Operations Department', 0),
('Research', 'Research and Development', 0),
('Support', 'Customer Support', 0),
('Logistics', 'Logistics Department', 0);

-- Insert more dummy data for موظفين (Employees)
INSERT INTO `موظفين` (`رقم_الموظف`, `قسم`, `اسم_الموظف`, `تاريخ_الميلاد`, `رقم_الهاتف`, `وظيفة`, `تاريخ_التوظيف`, `مدفوع_الراتب`, `تاريخ_دفع_الراتب`, `أيام_الإجازة_السنوية`, `أيام_الإجازة_التي_استخدمت`) VALUES
(1, 'IT', 'John Doe', '1980-01-01', '1234567890', 'Developer', '2020-01-01', TRUE, '2023-01-01', 30, 10),
(2, 'HR', 'Jane Smith', '1985-02-02', '1234567891', 'HR Manager', '2019-02-02', TRUE, '2023-02-02', 25, 5),
(3, 'Finance', 'Robert Brown', '1990-03-03', '1234567892', 'Accountant', '2018-03-03', TRUE, '2023-03-03', 20, 8),
(4, 'Marketing', 'Emily Davis', '1995-04-04', '1234567893', 'Marketing Specialist', '2017-04-04', TRUE, '2023-04-04', 15, 7),
(5, 'Sales', 'Michael Wilson', '1988-05-05', '1234567894', 'Sales Representative', '2021-05-05', TRUE, '2023-05-05', 10, 3),
(6, 'Legal', 'Anna Taylor', '1983-06-06', '1234567895', 'Legal Advisor', '2016-06-06', TRUE, '2023-06-06', 20, 5),
(7, 'Operations', 'David Moore', '1975-07-07', '1234567896', 'Operations Manager', '2015-07-07', TRUE, '2023-07-07', 25, 12),
(8, 'Research', 'Emma Anderson', '1992-08-08', '1234567897', 'Research Scientist', '2022-08-08', TRUE, '2023-08-08', 15, 2),
(9, 'Support', 'Christopher Lee', '1987-09-09', '1234567898', 'Support Specialist', '2014-09-09', TRUE, '2023-09-09', 18, 9),
(10, 'Logistics', 'Sarah Lewis', '1982-10-10', '1234567899', 'Logistics Coordinator', '2013-10-10', TRUE, '2023-10-10', 22, 6),
(11, 'IT', 'William White', '1981-11-11', '1234567810', 'System Administrator', '2012-11-11', TRUE, '2023-11-11', 28, 11),
(12, 'HR', 'Jessica Hall', '1986-12-12', '1234567811', 'Recruiter', '2021-12-12', TRUE, '2023-12-12', 20, 4),
(13, 'Finance', 'James Harris', '1979-01-13', '1234567812', 'Financial Analyst', '2020-01-13', TRUE, '2023-01-13', 25, 7),
(14, 'Marketing', 'Patricia Martin', '1991-02-14', '1234567813', 'Brand Manager', '2019-02-14', TRUE, '2023-02-14', 22, 8),
(15, 'Sales', 'Charles Martinez', '1993-03-15', '1234567814', 'Sales Executive', '2018-03-15', TRUE, '2023-03-15', 15, 3);

-- Insert more dummy data for حوادث_الموظفين (Employee Incidents)
INSERT INTO `حوادث_الموظفين` (`رقم_الحادث`, `رقم_الموظف`, `سبب_الحادث`, `وصف_الحادث`, `تاريخ_الحادث`, `الخطورة`) VALUES
(1, 1, 'Accident', 'Fell down the stairs', '2023-01-01', 'High'),
(2, 1, 'Illness', 'Flu', '2023-02-01', 'Medium'),
(3, 2, 'Accident', 'Car accident', '2023-03-01', 'High'),
(4, 2, 'Accident', 'Slipped on wet floor', '2023-04-01', 'Low'),
(5, 2, 'Illness', 'COVID-19', '2023-05-01', 'High'),
(6, 3, 'Illness', 'Migraine', '2023-06-01', 'Low'),
(7, 6, 'Accident', 'Office furniture fall', '2023-07-01', 'Medium'),
(8, 9, 'Accident', 'Burned hand', '2023-08-01', 'Low'),
(9, 9, 'Illness', 'Stomach flu', '2023-09-01', 'Medium'),
(10, 10, 'Accident', 'Fell off chair', '2023-10-01', 'Low');

-- Insert more dummy data for مجموعات_الطلاب (Student Groups)
INSERT INTO `مجموعات_الطلاب` (`رقم_المجموعة`, `عدد_الطلاب`, `وصف_المجموعة`) VALUES
(1, 0, 'Group A'),
(2, 0, 'Group B'),
(3, 0, 'Group C');

-- Insert more dummy data for مسؤولون_مجموعة_الطلاب (Student Group Managers)
INSERT INTO `مسؤولون_مجموعة_الطلاب` (`رقم_المسئول`, `رقم_المجموعة`) VALUES
(1, 1),
(2, 1),
(3, 2),
(5, 2),
(8, 2),
(12, 3),
(15, 3);

-- Insert more dummy data for الغرف (Rooms)
INSERT INTO `الغرف` (`رقم_الغرفة`, `موقع_الغرفة`, `مساحة_الغرقة`, `عدد_الأسر`, `عدد_الطلاب`, `الحد_الاقصى`, `الحالة`, `وجود_وسع`) VALUES
(1, 'Building A, Room 101', '20 sqm', 3, 0, 10, 'Available', TRUE),
(2, 'Building B, Room 202', '25 sqm', 2, 0, 8, 'Occupied', FALSE),
(3, 'Building C, Room 303', '30 sqm', 1, 0, 6, 'Under Maintenance', FALSE),
(4, 'Building D, Room 404', '35 sqm', 2, 0, 12, 'Available', TRUE),
(5, 'Building E, Room 505', '40 sqm', 3, 0, 15, 'Occupied', FALSE);

-- Insert more dummy data for الطلاب (Students)
INSERT INTO `الطلاب` (`رقم_الطالب`, `رقم_المجموعة`, `رقم_الغرفة`, `اسم_الطالب`, `تاريخ_الميلاد`, `رقم_الهاتف`) VALUES
(1, 1, 1, 'Alice Johnson', '2000-01-01', '1234567895'),
(2, 2, 2, 'Bob White', '2001-02-02', '1234567896'),
(3, 3, 3, 'Charlie Green', '2002-03-03', '1234567897'),
(4, 1, 4, 'Diana Black', '2003-04-04', '1234567898'),
(5, 2, 5, 'Edward Brown', '2004-05-05', '1234567899'),
(6, 3, 1, 'Fiona Smith', '2005-06-06', '1234567800'),
(7, 1, 2, 'George Martin', '2006-07-07', '1234567801'),
(8, 2, 3, 'Hannah Lee', '2007-08-08', '1234567802'),
(9, 3, 4, 'Ivan Wilson', '2008-09-09', '1234567803'),
(10, 3, 5, 'Julia Brown', '2009-10-10', '1234567804');

-- Insert more dummy data for حوادث_الطلاب (Student Incidents)
INSERT INTO `حوادث_الطلاب` (`رقم_الحادث`, `رقم_الطالب`, `وصف_الحادث`, `تاريخ_الحادث`, `الخطورة`) VALUES
(1, 1, 'Fell during sports', '2023-01-01', 'High'),
(2, 6, 'Food poisoning', '2023-02-01', 'Medium'),
(3, 7, 'Minor cut', '2023-03-01', 'Low'),
(4, 2, 'Broke a leg', '2023-04-01', 'High'),
(5, 2, 'Fainted', '2023-05-01', 'Medium'),
(6, 1, 'Sprained ankle', '2023-06-01', 'Low'),
(7, 8, 'Severe headache', '2023-07-01', 'Medium'),
(8, 9, 'Fell off bike', '2023-08-01', 'High'),
(9, 4, 'Burned hand', '2023-09-01', 'Low'),
(10, 4, 'Stomach ache', '2023-10-01', 'Medium');

-- Insert more dummy data for المجال_الحركي (Motor Aspect)
INSERT INTO `المجال_الحركي` (`رقم_نموذج_المجال_الحركي`, `رقم_الطالب`, `الاتزان_اثناء_الحركة`, `اصعاد_ونزول_الدرج`, `ضغط_على_الكرة_الاسفنجية`, `قفز_من_ارتفاع_محدد`) VALUES
(1, 1, 'Good', 'Good', 'Strong', 'High'),
(2, 2, 'Average', 'Good', 'Medium', 'Medium'),
(3, 3, 'Poor', 'Poor', 'Weak', 'Low'),
(4, 4, 'Good', 'Average', 'Strong', 'High'),
(5, 5, 'Average', 'Good', 'Medium', 'Medium'),
(6, 6, 'Good', 'Good', 'Strong', 'High'),
(7, 7, 'Average', 'Average', 'Medium', 'Medium'),
(8, 8, 'Poor', 'Poor', 'Weak', 'Low'),
(9, 9, 'Good', 'Good', 'Strong', 'High'),
(10, 10, 'Average', 'Good', 'Medium', 'Medium');

-- Insert more dummy data for المجال_الاجتماعي (Social Aspect)
INSERT INTO `المجال_الاجتماعي` (`رقم_نموذج_المجال_الاجتماعي`, `رقم_الطالب`, `مصافحة_من_تلقاء_نفسه`, `التحية_على_الاخرين`, `طرق_الباب_قبل_الدخول`, `تقبل_الغرباء`) VALUES
(1, 1, 'Yes', 'Yes', 'Yes', 'No'),
(2, 2, 'No', 'Yes', 'No', 'Yes'),
(3, 3, 'Yes', 'No', 'Yes', 'Yes'),
(4, 4, 'No', 'Yes', 'No', 'No'),
(5, 5, 'Yes', 'Yes', 'Yes', 'Yes'),
(6, 6, 'No', 'Yes', 'No', 'No'),
(7, 7, 'Yes', 'No', 'Yes', 'Yes'),
(8, 8, 'No', 'Yes', 'No', 'No'),
(9, 9, 'Yes', 'Yes', 'Yes', 'Yes'),
(10, 10, 'No', 'No', 'No', 'No');

-- Insert more dummy data for المجال_الاستقلالي (Independence Aspect)
INSERT INTO `المجال_الاستقلالي` (`رقم_نموذج_المجال_الاستقلالي`, `رقم_الطالب`, `استخدام_الحمام`, `غسل_اليدين_وتنشيف`, `لبس_وخلع_الملابس`, `تناول_الطعام_باستقلال`, `فرش_الاسنان`) VALUES
(1, 1, 'Good', 'Good', 'Good', 'Good', 'Average'),
(2, 2, 'Average', 'Good', 'Good', 'Average', 'Poor'),
(3, 3, 'Poor', 'Average', 'Average', 'Poor', 'Poor'),
(4, 4, 'Good', 'Good', 'Good', 'Good', 'Good'),
(5, 5, 'Average', 'Good', 'Good', 'Average', 'Average'),
(6, 6, 'Good', 'Good', 'Good', 'Good', 'Good'),
(7, 7, 'Average', 'Average', 'Average', 'Average', 'Poor'),
(8, 8, 'Poor', 'Poor', 'Poor', 'Poor', 'Poor'),
(9, 9, 'Good', 'Good', 'Good', 'Good', 'Good'),
(10, 10, 'Average', 'Good', 'Good', 'Average', 'Average');

-- Insert more dummy data for المجال_الادراكي (Cognitive Aspect)
INSERT INTO `المجال_الادراكي` (`رقم_نموذج_المجال_الادراكي`, `رقم_الطالب`, `مطابقة_الاشياء_المماثلة`, `مطابقة_الاشكال_الهندسية`, `تسمية_الالوان_الاساسية`, `مطابقة_الاحجام`) VALUES
(1, 1, 'Excellent', 'Good', 'Average', 'Good'),
(2, 2, 'Good', 'Good', 'Good', 'Good'),
(3, 3, 'Average', 'Poor', 'Poor', 'Poor'),
(4, 4, 'Good', 'Good', 'Good', 'Good'),
(5, 5, 'Average', 'Good', 'Average', 'Good'),
(6, 6, 'Good', 'Good', 'Good', 'Good'),
(7, 7, 'Average', 'Average', 'Average', 'Average'),
(8, 8, 'Poor', 'Poor', 'Poor', 'Poor'),
(9, 9, 'Good', 'Good', 'Good', 'Good'),
(10, 10, 'Average', 'Good', 'Average', 'Good');

-- Insert more dummy data for نموذج_طبي (Medical Record)
INSERT INTO `نموذج_طبي` (`رقم_النموذج_الطبي`, `رقم_الطالب`, `تشخيص`, `وصفة_طبية`, `حساسية_للادوية`, `حساسية_للطعام`) VALUES
(1, 1, 'Asthma', 'Inhaler', 'No', 'Yes'),
(2, 2, 'Diabetes', 'Insulin', 'Yes', 'No'),
(3, 3, 'Epilepsy', 'Medication', 'No', 'No'),
(4, 4, 'Allergies', 'Antihistamines', 'Yes', 'Yes'),
(5, 5, 'Anemia', 'Iron Supplements', 'No', 'No'),
(6, 6, 'Asthma', 'Inhaler', 'No', 'No'),
(7, 7, 'Diabetes', 'Insulin', 'Yes', 'Yes'),
(8, 8, 'Epilepsy', 'Medication', 'No', 'No'),
(9, 9, 'Allergies', 'Antihistamines', 'Yes', 'Yes'),
(10, 10, 'Anemia', 'Iron Supplements', 'No', 'No');